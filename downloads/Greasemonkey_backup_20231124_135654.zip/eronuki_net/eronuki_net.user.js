// ==UserScript==
// @name eronuki_net
// @description 1st, hope not last userscript
// @version 1.0
// @include https://ero-nuki.net/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var selectorTxt = 'div.product-more'
    var timerId = 0;

    // https://stackoverflow.com/questions/1208222/how-to-do-associative-array-hashing-in-javascript
    var dictionary = {};
    var myMap = new Map();


    // [4] дополнительная проверка наряду с @include
    if (/\/ero-nuki.net/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('ero-nuki.net', now);
        console.log(w.location.href);

        // MutationObserver code example
        var target = document.documentElement;
        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;

            console.log('callback:', timerId, mutationsList.length, div.length);
            /*
            console.log(document.cookie);
            var cookie = document.cookie.split('; ');
            for (var i = 0; i < cookie.length; ++i) {
                console.log(i, cookie[i]);
            }
            */
        };  // callback

        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        //const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        //observer.observe(target, config);

    } else {
        console.log('--------------------------------');
        console.log('fevian.org something wrong', now);
        console.log(w.location.href);
    }  // test(w.location.href)



    document.onreadystatechange = function() {
        console.log('document.readyState:', document.readyState);
        console.log('--------------------------------');

        if (document.readyState == "complete") {
            var div = document.getElementById('movie_iframe')
                               
            console.log('document.getElementById(movie_iframe)', typeof(div), div);


        }  // document.readyState == "complete"

    }  // document.onreadystatechange()

})(window);

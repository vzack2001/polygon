// ==UserScript==
// @name     jav.guru
// @version  1
// @grant    none
// @include https://jav.guru/*
// ==/UserScript==

(function (window, undefined) { 

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var timerId = 0;

    if (/jav.guru/.test(w.location.href)) {

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('jav.guru', now);
        console.log(w.location.href);


    } else {
        console.log('--------------------------------');
        console.log('jav.guru something wrong', now);
        console.log(w.location.href);
    }  // test(w.location.href)



    document.onreadystatechange = function() {
        console.log('document.readyState:', document.readyState);

        if (document.readyState == "complete") {
            var contents = document.getElementById("content");
            console.log('content:', contents);

            var video = contents.getElementsByClassName("inside-right-sidebar");
            console.log(video.length);
            for(var i=0; i<video.length; i++) {
                console.log('i:', i);
            }
          
            var main1 = document.getElementById("main");
            console.log('main:', main1);

        }  // document.readyState == "complete"
      
        console.log('--------------------------------');

    }  // document.onreadystatechange()

})(window);

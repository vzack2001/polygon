// ==UserScript==
// @name kissjav
// @description kissjav
// @author v.zack
// @version 1.0
// @include https://kissjav.com/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var timerId = 0;

    // [4] дополнительная проверка наряду с @include
    if (/\/kissjav.com/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('kissjav', now);
        console.log(w.location.href);

        //https://developer.mozilla.org/ru/docs/Web/API/MutationObserver
        //https://habr.com/ru/company/ruvds/blog/351256/
        //MutationObserver

        // Выбираем целевой элемент
        //var target = document.getElementById('some-id');
        //var target = document.querySelector(selectorTxt)  //'div.product-more'
        var target = document.documentElement

        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;
            console.time('callback:', timerId, mutationsList.length);

            if (document.readyState == "complete") {

                console.log('complete:', timerId, mutationsList.length);

                var sections = document.getElementsByTagName('noscript')
                console.log('noscript:', sections.length);
                for(var i=0; i<sections.length; i++) {
                    //console.log(sections[i].className);
                    console.log(i, sections[i].innerText);
                }
                if(sections.length>0){
                    console.log('--------------------------------');
                }
                /*

                // -------------------------------- remove unused elements (banners, helpers, add-ons, etc)

                "https://media7.kissjav.com/media/videos/mp4/34374_480p.mp4?st=kuOAb8bjWHoxH0N9GiAA_g&e=1600430672"
                https://kissjav.com/filev.php?id=34374&file_id=34038&server=9&hash=02a4c49826251a670e2e&expire=1600351469&file=/mp4/34374_480p.mp4

                */

                //console.log('-------------------------------- data');
            } //if(document.readyState == "complete")

            //console.timeEnd('--------------------------------');
        };

        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);



    } else { //.test(w.location.href)
        console.log('--------------------------------');
        console.log('009am something wrong', now);
        console.log(w.location.href);
    }

    /*
    document.onreadystatechange = function() {
        //console.log('document.readyState=', document.readyState);

        //https://github.com/nokeya/direct-links-out/blob/master/direct-links-out.user.js

        if (document.readyState == "complete") {

            //document.body.innerHTML = document.body.innerHTML.replace(/aliexpress.ru/g, 'aliexpress.com');
            //https://www.lifewire.com/top-greasemonkey-tampermonkey-user-scripts-4134335
            //https://stackoverflow.com/questions/5890110/greasemonkey-script-to-work-on-dynamically-loaded-posts-on-facebook

        } //if(document.readyState == "complete")
    } //document.onreadystatechange
    */



})(window);

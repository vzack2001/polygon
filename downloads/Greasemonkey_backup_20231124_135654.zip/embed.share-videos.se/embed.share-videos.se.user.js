// ==UserScript==
// @name     embed.share-videos.se
// @version  1
// @grant    none
// @include https://*.share-videos.se/*
// ==/UserScript==

(function (window, undefined) {

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    if (w.self != w.top) {
        return;
    }

    document.onreadystatechange = function() {
      
        if (document.readyState == "complete") {
            var el = document.getElementById('ad_html');
            console.log('1 ad_html:', el);
            el.remove();
          
            el = document.getElementById('new_ad_html');
            console.log('2 new_ad_html:', el);
            el.remove();
          
            el = document.getElementById('logo');
            console.log('3 logo:', el);
            el.remove();
          
        } // document.readyState == "complete"
    } // document.onreadystatechange

})(window);

// ==UserScript==
// @name AliExpress
// @description 1st, hope not last userscript
// @author Vasya Pupkin
// @version 1.0
// @include https://*.aliexpress.com/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var selectorTxt = 'div.product-more'
    var timerId = 0;

    // [4] дополнительная проверка наряду с @include
    if (/\/*.aliexpress.com/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //console.log('--------------------------------');
        console.log('aliexpress', now);
        console.log(w.location.href);


        //https://developer.mozilla.org/ru/docs/Web/API/MutationObserver
        //https://habr.com/ru/company/ruvds/blog/351256/
        //MutationObserver

        // Выбираем целевой элемент
        //var target = document.getElementById('some-id');
        //var target = document.querySelector(selectorTxt)  //'div.product-more'
        var target = document.documentElement

        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;

            if (document.readyState == "complete") {
                console.log('\ncallback:', timerId, mutationsList.length, w.navigator.language);

                for (let i = 0; i < mutationsList.length; ++i) {
                    let mutation = mutationsList[i]
                    console.log(timerId, i, mutation.type, mutation);
                }
                /*
                for (let mutation of mutationsList) {
                    if (mutation.type === 'childList') {
                        console.log('A child node has been added or removed:', mutation);
                    } else if (mutation.type === 'subtree') {
                        console.log('A subtree was modified:', mutation);
                    }
                }
                
                console.log(document.cookie);
                var cookie = document.cookie.split('; ');
                for (var i = 0; i < cookie.length; ++i) {
                    console.log(i, cookie[i]);
                }
                */
                get_info();
                //console.log(timerId, len(mutationsList));
                //for (let mutation of mutationsList) {
                //    console.log(mutation);
                //}

                //w.page_params.lazyLoad.sections = [];
                //delete w.page_params.lazyLoad;
                /*
                var img = document.querySelectorAll('img');  // [129]
                //var img = document.getElementsByClassName('lazy'); //[89] //document.querySelectorAll('img') // [129]
                console.log('document.querySelectorAll(lazy):', timerId, img.length);
                for(let i=0; i<img.length; i++) {
                    img[i].setAttribute('loading', 'eager')
                    //console.log(i, img[i].nodeName, img[i].getAttribute('loading'), img[i]); //
                }
                */
            }
        }  // callback()

        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);


        /*
        var mutationObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                console.log(mutation);
            });
        });

        mutationObserver.observe(document.documentElement, {
            attributes: true,
            characterData: true,
            childList: true,
            subtree: true,
            attributeOldValue: true,
            characterDataOldValue: true
        });
        */

    } else {
        console.log('--------------------------------');
        console.log('aliexpress something wrong', now);
        console.log(w.location.href);
    }



    function get_info(starttime) {

        //var enter = new Date();
        //console.log(':', enter - starttime);
        var anchor = '?';

        var links = document.getElementsByTagName('a');
        for (var i = 0; i < links.length; ++i) {
            //console.log(i);

            links[i].href = links[i].href.replace(/aliexpress.ru/g, 'aliexpress.com');

            if (/https:\/\/aliexpress.com\/item/.test(links[i].href)) {
                var ndx = links[i].href.indexOf(anchor);
                if (ndx != -1){
                    links[i].href = links[i].href.substring(0, ndx);
                    //console.log(i, ndx, links[i].href);
                }
            }
            if (/https:\/\/www.aliexpress.com\/item/.test(links[i].href)) {
                var ndx = links[i].href.indexOf(anchor);
                if (ndx != -1){
                    links[i].href = links[i].href.substring(0, ndx);
                    //console.log(i, ndx, links[i].href);
                }
            }
          //if (/\/item/.test(links[i].href)) {
                //console.log(i, links[i]);
                //console.log(links[i].outerHTML);
                //console.log(i, links[i].href);
                //console.log(links[i].click);
                //console.log(links[i].onclick);
                //console.log('\n');
            //}

            //if (/aliexpress.ru/.test(links[i].href)) {
            //    links[i].style.background = 'red';
            //}
        }

        //document.body.style.border = "5px solid red";
        //console.log('-------------------------------- complete');

      //console.log(runParams.data.imageModule.imagePathList);

    }  // get_info()



/*--- waitForKeyElements():  A utility function, for Greasemonkey scripts,

https://gist.github.com/BrockA/2625891

*/

})(window);



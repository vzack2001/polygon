// ==UserScript==
// @name AliExpressRU
// @description 1st, hope not last userscript
// @author Vasya Pupkin
// @version 1.0
// @include https://*aliexpress.ru/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var selectorTxt = 'div.product-more'
    var timerId = 0;

    // [4] дополнительная проверка наряду с @include
    if (/\/*aliexpress.ru/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //console.log('--------------------------------');
        console.log('aliexpress', now);
        console.log(w.location.href);
      

        //timerId = setInterval(function() {
            //waitFor(selectorTxt, true); 
        //    get_info();
        //}, 2000);

      

        
        //https://developer.mozilla.org/ru/docs/Web/API/MutationObserver
        //https://habr.com/ru/company/ruvds/blog/351256/
        //MutationObserver
      
        // Выбираем целевой элемент
        //var target = document.getElementById('some-id');
        //var target = document.querySelector(selectorTxt)  //'div.product-more'
        var target = document.documentElement
        
        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;
            console.log('callback:', timerId, mutationsList.length, w.navigator.language);
          
          	console.log(document.cookie);
          	var cookie = document.cookie.split('; ');
        		for (var i = 0; i < cookie.length; ++i) {
            	console.log(i, cookie[i]);
            }

          	get_info();
            //console.log(timerId, len(mutationsList));
            //for (let mutation of mutationsList) {
            //    console.log(mutation);
            //}
        };
      
        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);

        
        /*
        var mutationObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                console.log(mutation);
            });
        });
      
        mutationObserver.observe(document.documentElement, {
            attributes: true,
            characterData: true,
            childList: true,
            subtree: true,
            attributeOldValue: true,
            characterDataOldValue: true
        });
        */
      
    } else {
        console.log('--------------------------------');
        console.log('aliexpress something wrong', now);
        console.log(w.location.href);
    }

  
  
    /*
    document.onreadystatechange = function() {
        console.log('document.readyState=', document.readyState);
        
        //https://github.com/nokeya/direct-links-out/blob/master/direct-links-out.user.js

        if (document.readyState == "complete") {
            
            //document.body.innerHTML = document.body.innerHTML.replace(/aliexpress.ru/g, 'aliexpress.com');
            //https://www.aliexpress.com/item/32866959979.html
            //https://www.lifewire.com/top-greasemonkey-tampermonkey-user-scripts-4134335
            //https://stackoverflow.com/questions/5890110/greasemonkey-script-to-work-on-dynamically-loaded-posts-on-facebook
          
            //html body.glo-detail-page div#root div.glodetail-wrap div.product-extend div.detail-container.container.flex div#product-detail.product-detail div.bottom-recommendation div.product-more
            //div.product-more:nth-child(1)
            
            //html body.glo-detail-page div#root div.glodetail-wrap div.product-extend div.detail-container.container.flex div#product-detail.product-detail div.bottom-recommendation div.product-more div.other-store-more
            //div.bottom-recommendation div.product-more div.other-store-more
            
            //html body.glo-detail-page div#root div.glodetail-wrap div.product-main div.product-main-wrap div.may-like
            //div.may-like
          
            //get_info(now)

        } // document.readyState == "complete"

    } // document.onreadystatechange
    */
    
    function get_info(starttime) {

        //var enter = new Date();
        //console.log(':', enter - starttime);
        var anchor = '?';
      
        var links = document.getElementsByTagName('a');
        for (var i = 0; i < links.length; ++i) {
            //console.log(i);
            
            links[i].href = links[i].href.replace(/aliexpress.ru/g, 'aliexpress.com');

            if (/https:\/\/aliexpress.com\/item/.test(links[i].href)) {
                var ndx = links[i].href.indexOf(anchor);
                if (ndx != -1){
                    links[i].href = links[i].href.substring(0, ndx);
                    //console.log(i, ndx, links[i].href); 
                }
            }
            if (/https:\/\/www.aliexpress.com\/item/.test(links[i].href)) {
                var ndx = links[i].href.indexOf(anchor);
                if (ndx != -1){
                    links[i].href = links[i].href.substring(0, ndx);
                    //console.log(i, ndx, links[i].href); 
                }
            }
          //if (/\/item/.test(links[i].href)) {
                //console.log(i, links[i]);
                //console.log(links[i].outerHTML);
                //console.log(i, links[i].href);
                //console.log(links[i].click);
                //console.log(links[i].onclick);
                //console.log('\n');
            //}
          
            //if (/aliexpress.ru/.test(links[i].href)) {
            //    links[i].style.background = 'red';
            //}
        }
                    
        //document.body.style.border = "5px solid red";
        //console.log('-------------------------------- complete');
      
    }  // get_info()



/*--- waitForKeyElements():  A utility function, for Greasemonkey scripts,
   
https://gist.github.com/BrockA/2625891
    
*/
function waitFor(
    selectorTxt,    // Required: The jQuery selector string that specifies the desired element(s).
    bWaitOnce       // Optional: If false, will continue to scan for new elements even after the first match is found.
) {

    var btargetsFound = false;
    var targetNodes = document.querySelector(selectorTxt)

    if (targetNodes) {
        btargetsFound = true;
        
        var from_now = new Date();

        console.log('targetNodes:', from_now - now);
        //console.log(targetNodes);
        
        //get_info();
        
        clearInterval(timerId);
        
       
        //timerId = setTimeout(function() {get_info(from_now);}, 10000);
        timerId = setTimeout(function() {get_info(from_now);}, 10000);
    
    } else {
        btargetsFound = false;
        //console.log(timerId);
    }
} //waitForKeyElements


})(window);



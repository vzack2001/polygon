// ==UserScript==
// @name     spankbang.com
// @version  1
// @grant    none
// @include https://*.spankbang.com/*
// ==/UserScript==

(function (window, undefined) { 

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var timerId = 0;

    if (/spankbang.com/.test(w.location.href)) {

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('spankbang.com', now);
        console.log(w.location.href);


    } else {
        console.log('--------------------------------');
        console.log('spankbang.com something wrong', now);
        console.log(w.location.href);
    }  // test(w.location.href)



    document.onreadystatechange = function() {
        console.log('document.readyState:', document.readyState);

        if (document.readyState == "complete") {
            var contents = document.getElementById("container");
            console.log('container:', contents);

            var video = document.getElementsByClassName("video-item");
            console.log(video.length);
            for(var i=0; i<video.length; i++) {
                var innerHTML = video[i].innerHTML;
                //console.log(i, innerHTML); //video[i]
                // <a href="/66vma/video/charming+female+neighbor" class
                //var href = innerHTML.match(/<a\s+href\s*=\"(.*)\"\s+class/i) || [];
                var href = innerHTML.match(/<a\s+href\s*=\"(.*?)\"/i) || [];
                if (href.length > 1) {
                    href = href[1];
                    if (/\/video\//.test(href)) {
                        //console.log('href:\n', href);
                        console.log(i);
                        console.log('https://jp.spankbang.com'+href);
                    }
                }
                //div[i].remove();
            }
          
            //contents = document.getElementById("video_container");
            var stream_data = w.stream_data;
            if (typeof stream_data !== 'undefined') {
                console.log('\nstream_data:', stream_data);
                console.log('stream_data[main]:\n', stream_data['main'][0]);
                console.log('stream_data[720p]:\n', stream_data['720p'][0]);
            }

            var video_id = w.ana_video_id;
            console.log('\nvideo_id:\n', video_id);
          
            var live_keywords = w.live_keywords;
            console.log('live_keywords:\n', live_keywords);
          
          	var location = w.location.href;
            console.log('location:\n', location);

            let result = location.split(/spankbang.com/)[1]; // || [];
            console.log('result:\n', result);
            result = result.split(/\//) || [];
            console.log('result:\n', result.join('-'));
          

        }  // document.readyState == "complete"
      
        console.log('--------------------------------');

    }  // document.onreadystatechange()

})(window);

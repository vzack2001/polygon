// ==UserScript==
// @name metro
// @version 1.0
// @include https://*.metro-cc.ru/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var timerId = 0;


    //MutationObserver
    // Выбираем целевой элемент
    var target = document.documentElement;

    // Конфигурация observer (за какими изменениями наблюдать)
    const config = {
       //attributes: true,
       childList: true,
       subtree: true
    };

  	console.log("metro", now);
    // callback function при срабатывании мутации
    const callback = function(mutationsList, observer) {
       timerId++;
      
       if (document.readyState == "complete") {
         
          var links = document.getElementsByTagName('a');
         
          console.log('callback:', timerId, mutationsList.length, links.length);
  	
           for (var i = 0; i < links.length; ++i) {
              if (/\w\/\/\w/.test(links[i].href)) {  // bakaleya//krupy-bobovye
                 //console.log(i, links[i]);
                 links[i].href = links[i].href.replace(/(\w)\/\/(\w)/, '$1/$2');
                 console.log(i, links[i].href);
              }
           }
  
       }
 
    }  // callback()

    // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
    const observer = new MutationObserver(callback);

    // Начинаем наблюдение за настроенными изменениями целевого элемента
    observer.observe(target, config);

  /*
    document.onreadystatechange = function() {
      
        console.log(w.location.href, document.readyState);

        if (document.readyState == "complete") {
          
           console.log("complete", document.readyState);
           var links = document.getElementsByTagName('a');
           for (var i = 0; i < links.length; ++i) {
              if (/\w\/\/\w/.test(links[i].href)) {  // bakaleya//krupy-bobovye
                 console.log(i, links[i].href);
                 links[i].href = links[i].href.replace(/(\w)\/\/(\w)/, '$1/$2');
                 console.log(i, links[i].href);
              }
           }
          
        } // document.readyState == "complete"
    
    } // document.onreadystatechange
*/

})(window);


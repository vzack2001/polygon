// ==UserScript==
// @name     e2e4online
// @version  1
// @include https://*.e2e4online.ru/*
// @grant    none
// ==/UserScript==

(function (window, undefined) {         // [2] нормализуем window

        console.log('--------------------------------');

  var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  if (w.self != w.top) {
    return;
  }

  var now = new Date();
  var timerId = 0;
  
  if (/e2e4online.ru/.test(w.location.href)) {
  
        console.log('e2e4online', now);
    
        // Выбираем целевой элемент
        var target = document.documentElement;

        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };
    
        // mutation callback func
        const callback = function(mutationsList, observer) {
            timerId++;


            if (document.readyState == "complete") {
              
             		//console.log('document.readyState:', document.readyState, timerId, mutationsList.length);

                var banners = document.getElementsByClassName('mxpromo');
                //console.log('search-result:', banners.length);
                for(let i=banners.length-1; i>=0; i--) {
	              	  console.log('mxpromo remove:', i, banners[i]);
                    banners[i].remove();
                }
              
            } // document.readyState == "complete" 'data-category-id'

        }  // callback()

        
        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);
        
        
  } else { //.test(w.location.href)
        console.log('e2e4online something wrong', now);
        console.log(w.location.href);
  };  // if (/e2e4online.ru/.test(w.location.href))
  
        console.log('--------------------------------');

})(window);  
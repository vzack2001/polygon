// ==UserScript==
// @name 009am
// @description 009.рф //nuxt  https://habr.com/ru/search/?q=Nuxt#h  https://habr.com/ru/post/490496/
// @author v.zack
// @version 1.0
// @include https://009.xn--p1ai/*
// @grant    browser
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
// https://stackoverflow.com/questions/10824697/why-is-window-and-unsafewindow-not-the-same-from-a-userscript-as-from-a-scrip
(function (window, undefined) {         // [2] нормализуем window

        console.log('--------------------------------');

  var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

  // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var timerId = 0;
    var change_css = false;

    // [4] дополнительная проверка наряду с @include
    if (/\/009.xn--p1ai/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //document.body.style.border = "5px solid red";
        console.log('009am', now);
        console.log(w.location.href);

        //https://developer.mozilla.org/ru/docs/Web/API/MutationObserver
        //https://habr.com/ru/company/ruvds/blog/351256/
        //MutationObserver

        // Выбираем целевой элемент
        var target = document.documentElement;

        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;
            //console.log('callback:', timerId, mutationsList.length);

            if (document.readyState == "complete") {
                //console.log('document.readyState:', document.readyState, timerId, mutationsList.length);

                var header = document.getElementsByTagName('header');
                //console.log('header:', header.length);
                for(let i=header.length-1; i>=0; i--) {
                    //console.log('header:', i, header[i]);
                    header[i].remove();
                }

                var footer = document.getElementsByTagName('footer');
                //console.log('footer:', footer.length);
                for(let i=footer.length-1; i>=0; i--) {
                    //console.log('footer:', i, footer[i]);
                    footer[i].remove();
                }
              
                // remove unuseful elements (banners, helpers, add-ons, etc) --------------------------------
                //class="banner-wrapper"
                //class="banner-wrapper"
                var banners = document.getElementsByClassName('banner-wrapper');
                //console.log('banner-wrapper:', banners.length);
                for(let i=banners.length-1; i>=0; i--) {
	              	  //console.log('banner-wrapper:', i, banners[i]);
                    banners[i].remove();
                }
              
                // remove specials
                banners = document.getElementsByClassName('search-result');
                //console.log('search-result:', banners.length);
                if(banners.length >= 2) {
                    //console.log('specials:', timerId, banners[0]);         //banners[0].style
                    banners[0].style.border = "5px solid rgb(97, 211, 212)"; //"5px solid red";
                    banners[0].remove();
                }
              
              	if (change_css) {
                    change_css = false;

                    console.log('document.readyState:', document.readyState, timerId, mutationsList.length);
                  
                    var re = '\.search__right.';

                    var search__right = document.getElementsByClassName('search__right')
                    console.log('search_right:', search__right.length);

                    if(search__right.length > 0){
                        //re = re + search__right[0].attributes[0].name + ']';
                        re = search__right[0].attributes[0].name;
                    }
                    console.log('re:', re);
                  
                    var styleSheets = document.styleSheets;
                    console.log('document.styleSheets.length:', styleSheets.length);
                  
                    // find all matching css rules
                    re = new RegExp(re);
                    console.log('find all matching css rules', timerId, re);
                  
                    for(let i=0; i<styleSheets.length; i++) {
                        //console.log('\nstyleSheets:', i, styleSheets[i].cssRules.length); //, styleSheets[i]
                      
                        for(let j=0; j<styleSheets[i].cssRules.length; j++) {
                            let rule = styleSheets[i].cssRules[j];  // CSSStyleRule
                            //console.log(i, j, rule);                    
                            if(rule.type==CSSRule.STYLE_RULE) {
                              
                              
                                if(re.test(rule.selectorText)) {
                              
                                    console.log(i, j, rule.cssText);   //rule.selectorText, 
                                  //console.log(i, j, styleSheets[i].cssRules[j]);                    
                                }
                              
                              
                            }
                        }
                      
                    }
                  
              
                }  // change_css===true
              
            } // document.readyState == "complete"
          
        }  // callback()
      
        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);

    } else { //.test(w.location.href)
        console.log('009am something wrong', now);
        console.log(w.location.href);
    };  // if (/\/009.xn--p1ai/.test(w.location.href))
  

})(window);

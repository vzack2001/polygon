// ==UserScript==
// @name     javynow
// @version  1
// @grant    none
// @include https://javynow.com/*
// ==/UserScript==

(function (window, undefined) {

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    if (w.self != w.top) {
        return;
    }

    document.onreadystatechange = function() {
        if (document.readyState == "complete") {
            var el = document.getElementsByClassName('banner-player');
                for(let i=0; i<el.length; i++) {
                   el[i].remove();
                  
                }
            el = document.getElementsByClassName('banner-player');
                for(let i=0; i<el.length; i++) {
                   el[i].remove();
                  
                }
        } // document.readyState == "complete"
    } // document.onreadystatechange

})(window);

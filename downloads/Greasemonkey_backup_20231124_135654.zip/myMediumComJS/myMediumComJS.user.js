// ==UserScript==
// @name myMediumComJS
// @description customize medium.com UX
// @author Vasya Pupkin
// @version 1.0
// @include https://medium.com/*
// ==/UserScript==
// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {  // [2] нормализуем window
    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
      if (w.self != w.top) {
        return;
    }
    // [4] дополнительная проверка наряду с @include
    if (/\/medium.com/.test(w.location.href)) {
      //Ниже идёт непосредственно код скрипта
      
      document.body.style.border = "5px solid red";
      var now = new Date();
      console.log('--------------------------------');
      console.log('myMediumComJS', now);
      console.log('--------------------------------');
      console.log(w.location.href);
      console.log('--------------------------------');
      
	    // Remove "Pardon identification"
      // body > div:nth-child(16)
			// /html/body/div[2]
      // id="susi-entry-point-post_prompt"
      // id="susi-sign-up-modal">
    	document.querySelector('body > div:nth-child(16)').remove();
    	#document.getElementById("susi-entry-point-post_prompt").remove();
    	#document.getElementById("susi-sign-up-modal").remove();

      /*
			//let timerId = setTimeout(getvideoinfo, 1000, now);
      //clearTimeout(timerId);
      let timerId = setInterval(getvideoinfo, 1000, now);
      //clearInterval after 10 seconds (остановить вывод через 10 секунд)
			setTimeout(() => { clearInterval(timerId); console.log('stop!'); }, 10000);
      */
      
    } else {
      console.log('- something wrong --------------');
      console.log(w.location.href);
      console.log('--------------------------------');
      /*
      var	loadScriptVar  		= [],
			    loadScriptUniqueId 	= [],
          isAdaptive  = false;
          
      var flashvars = '';
			var tmp = document.body.innerHTML;
      console.log('document.body.innerHTML.length=', tmp.length);

      //var flashvars_253092561 = {
      //var flashvars_235440621 = {"disable_sharebar":0,"htmlPauseRoll":"true","htmlPostRoll":"true","errorReports":"https:\/\/www.pornhub.com\/video\/problems\/235440621","autoplay":"true","autoreplay":"false","video_unavailable":"false","pauseroll_url":"","postroll_url":"","embedCode":"<iframe src=\"https:\/\/www.pornhub.com\/embed\/ph5d2c37aa70ee2\" frameborder=\"0\" width=\"560\" height=\"340\" scrolling=\"no\" allowfullscreen><\/iframe>","hidePostPauseRoll":false,"isHD":"true","video_duration":"5478","actionTags":"","link_url":"https:\/\/www.pornhub.com\/view_video.php?viewkey=ph5d2c37aa70ee2","related_url":"https:\/\/www.pornhub.com\/video\/player_related_datas?id=235440621","image_url":"https:\/\/ci.phncdn.com\/videos\/201907\/15\/235440621\/original\/(m=eaAaGwObaaaa)(mh=Lpj5MgZ5Yz7MDjOg)13.jpg","video_title":"sbvd-354","defaultQuality":[480,240,720,1080],"vcServerUrl":"\/svvt\/add?stype=svv&svalue=235440621&snonce=n7aht51yl1pmbm08&skey=51a3396d1c71ce73c3e42b57eebbb75b90b70c2aba8018616eaadc6f406b57bf&stime=1566381130","display_hd_upsell":true,"mediaDefinitions":[{"defaultQuality":false,"quality":1080,"format":"upsell","videoUrl":""},{"defaultQuality":false,"format":"mp4","quality":"720","videoUrl":"https:\/\/cv.phncdn.com\/videos\/201907\/15\/235440621\/720P_1500K_235440621.mp4?5JlY2R5z_EL4ncrJCbpgOJK2VXQWhUmuPxpXDRo59k_ySniL7GW0_-kXzeilRGaSLszg6cSlmXPpcOEGwPWl3hhksXSPd98iYBcoTIOM1xuCgdtKT5Zrgmz6_9YvieSXwTpyCctMyHP5QGz64B_Urd8Vcq6C1f_8WlMBgWsMvCZZFWRRDsJ7_UkzUoXs1yKkj8_2FTVATIgH"},{"defaultQuality":true,"format":"mp4","quality":"480","videoUrl":"https:\/\/cv.phncdn.com\/videos\/201907\/15\/235440621\/480P_600K_235440621.mp4?-uZmu5Qi4GVX6NyCGYyUQye1E2_ozL8wxjotOfMpciRpt_Ur9f83F0GDD_MSS4cEElh8WRUaY5hEMyIfuA-xq8Sl9ix8MjRbK3yqxMHomLpzaGO3agsAwwaEQab5uIsrFaNq4S2Uar31Ppn_kSJQBjTfc-1Zx7li9iwPgjwn6KsP68sjueKCGXjv8cDY0YeSMeU83kwLX-g"},{"defaultQuality":false,"format":"mp4","quality":"240","videoUrl":"https:\/\/cv.phncdn.com\/videos\/201907\/15\/235440621\/240P_400K_235440621.mp4?xSA5xa1F4F6uwT-zYrC6_n1zA_Uwsp0nkr2_cRX4__7oq1VGpsLedKpmM5SxVdwzaPTLWWJWkxanbKPbP3GTsPMUcSNRTZWHei6S3aGhZYlaeGNqBqacEr3v265kk5Gvw22vHLMGS7QS1zKK0UTtQcB6JYxtGuRjj4gmtia4EGJmZ2mWW5J0JqWtYbjM21sJ9F-U6YL_Pw"}],"isVertical":"false","video_unavailable_country":"false","mp4_seek":"ms","hotspots":[12362,474,446,331,517,300,267,275,281,280,279,296,299,286,286,285,271,250,247,253,253,236,228,210,220,220,239,226,221,227,223,209,190,156,150,148,147,144,142,243,136,130,129,128,125,127,121,119,113,115,131,143,151,152,141,117,110,112,105,112,114,121,123,120,125,129,128,131,132,122,117,118,116,123,124,125,123,128,143,160,150,150,137,131,128,111,115,111,103,108,111,115,109,123,129,119,112,112,111,97,94,95,98,91,84,85,87,81,83,95,109,104,112,105,85,84,95,96,109,103,95,96,114,111,109,104,100,108,134,125,114,113,99,107,90,98,88,83,79,76,75,85,80,81,86,93,89,84,81,77,86,81,79,81,93,96,89,83,72,76,68,64,69,79,76,85,84,78,85,84,83,79,80,83,87,83,74,71,67,71,76,82,77,74,84,78,73,71,68,71,70,73,63,61,54,55,52,49,49,49,47,52,50,60,70,65,65,64,68,71,68,64,61,57,62,61,59,57,59],"toprated_url":"https:\/\/www.pornhub.com\/video?o=tr&t=m","mostviewed_url":"https:\/\/www.pornhub.com\/video?o=mv&t=m","options":"show","cdn":"edgecast","startLagThreshold":1000,"outBufferLagThreshold":2000,"appId":"1111","service":"protrack","cdnProvider":"ec","tubesCmsPrerollConfigType":"new","prerollGlobalConfig":[],"thumbs":{"samplingFrequency":9,"type":"normal","cdnType":"regular","urlPattern":"https:\/\/ci.phncdn.com\/videos\/201907\/15\/235440621\/timeline\/160x90\/(m=eGCaiCObaaaa)(mh=CwUCqmLEiPH8n37L)S{24}.jpg","thumbHeight":"90","thumbWidth":"160"},"nextVideo":{"thumb":"https:\/\/ci.phncdn.com\/videos\/201907\/15\/235434331\/original\/(m=ecuKGgaaaa)(mh=4j5wCHKgccUuFMgL)16.jpg","duration":"7105","title":"oae-121","isHD":"1","nextUrl":"\/view_video.php?viewkey=ph5d2c2d2cdcaad"},"language":"en"};
      var result = tmp.match( /var flashvars_\d*\s*=\s*\{(.*?)\};/i );
      if ( result ) {
      	console.log('flashvars.match =', result.length);
      } else {
        //console.log('document.body.innerHTML =', tmp);
        //alert(tmp);
        result = tmp.match( /var mediastring(.*?);/i ); 
	      if ( result ) {
          console.log('mediastring.match =\n', w.mediastring); //.length
        } else {
          console.log('mediastring.match =\n', mediastring);
        }
      }
			*/
    }
  
document.onreadystatechange = function() {
	console.log('document.readyState=', document.readyState);

  if (document.readyState == "complete") {
    console.log("readyState == complete");

  }
} //document.onreadystatechange


})(window);

// ==UserScript==
// @name     habr
// @version  1
// @include https://habr.com/*
// @grant    none
// ==/UserScript==

(function (window, undefined) {         // [2] нормализуем window

        console.log('--------------------------------');

  var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;
  if (w.self != w.top) {
    return;
  }

  var now = new Date();
  var timerId = 0;
  
  let blocks = ["tm-header", 
                "tm-company-profile-card tm-company-article__profile-card", 
                "tm-base-layout__header tm-base-layout__header_is-sticky", 
                "tm-page__sidebar", 
                "tm-editoral-subscription",
                "tm-notice tm-comments__comment-notice tm-notice_positive", 
                "tm-project-block tm-project-block tm-project-block_variant-courses",
                "tm-project-block tm-project-block tm-project-block_variant-company-courses",
                "tm-project-block tm-project-block tm-project-block_variant-questions",
                "tm-project-block tm-project-block tm-project-block_variant-salary",
                "tm-project-block tm-project-block tm-project-block_variant-tasks",
                "tm-project-block tm-project-block tm-project-block_variant-vacancies",
                "tm-block tm-block tm-block_spacing-around",
                "tm-block tm-block tm-block_spacing-bottom",
                "tm-article-sticky-panel",
                "tm-notice tm-comments__comment-notice tm-notice_positive",
                "placeholder-wrapper", 
                "tm-footer-menu",
                "tm-footer"];

 
  if (/habr.com\/ru(.*?)\/articles\/\d+?\//.test(w.location.href)) {  // https://habr.com/ru/articles/761798/
  
        console.log('habr.com', now, w.location.href);
    
        // https://stackoverflow.com/questions/12897446/userscript-to-wait-for-page-to-load-before-executing-code-techniques
        //if use `w` instead `window` - get - Permission denied to access property "handleEvent"
    		window.addEventListener('load', function() {
    			  
            console.log('document.readyState:', document.readyState, timerId);
          
                // remove unnecessary blocks
                for(let i=0; i<blocks.length; i++) {
                    var banners = document.getElementsByClassName(blocks[i]);
                    console.log(blocks[i]+':', banners.length);
                    for(let j=banners.length-1; j>=0; j--) {
                        banners[j].remove();
                    }
                }

                // add href to header
                var baseURI = document.head.querySelector("[data-vue-meta]").baseURI;
          			console.log('baseURI:', baseURI);
          
                var banners = document.getElementsByTagName('h1');
                console.log('class="tm-title tm-title_h1":', banners.length);
                for(let i=banners.length-1; i>=0; i--) {
                    banners[i].innerHTML = '<a href="' + banners[0].baseURI + '">' + banners[0].innerHTML + '</a>';
                    //console.log('banner:', i, banners[i]);
                }
          
     		    /*
            */
          
				}, false);
    
           
        
  } else { //.test(w.location.href)
        console.log('habr.com something wrong', now);
        console.log(w.location.href);
  };  // if (/habr.com/.test(w.location.href))
  
        console.log('--------------------------------');

})(window);  
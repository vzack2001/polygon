// ==UserScript==
// @name     ero-sogu
// @version  1
// @include http://ero-sogu.work/*
// @grant    none
// ==/UserScript==

(function (window, undefined) {

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    if (w.self != w.top) {
        return;
    }

    // https://imagekit.io/blog/lazy-loading-images-complete-guide/#trigger-image-load-using-javascript-events
  	console.log('ero-sogu.work:', w.location.href);
  
    document.onreadystatechange = function() {
      
        console.log('document.readyState:', document.readyState);
      
        if (document.readyState == "complete") {
          
            var loadImages = document.querySelectorAll("img"); 
          
            for(var i=0; i<loadImages.length; i++) {
                //console.log('img:', i, loadImages[i]);
                console.log('img.className:', i, loadImages[i].className);
                console.log('img.src:', i, loadImages[i].src);
                //console.log('img.dataset:', i, loadImages[i].dataset);
              
            }

            //var lazyloadImages = document.querySelectorAll("lazy"); 
            var lazyloadImages = document.images
            console.log('"img/lazy":', loadImages.length, lazyloadImages.length);
            for(var i=0; i<lazyloadImages.length; i++) {
                console.log('img:', i, lazyloadImages[i]);
            }
          
          /*
            var el = document.getElementsByTagName('img');
            for(var i=0; i<el.length; i++) {
                console.log('img:', i, el[i]);
                console.log('img:', i, el[i].dataset);
              
            }
            */
          
        } // document.readyState == "complete"
      
    } // document.onreadystatechange

})(window);

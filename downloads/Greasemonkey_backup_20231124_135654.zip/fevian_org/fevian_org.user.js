// ==UserScript==
// @name fevian_org
// @description 1st, hope not last userscript
// @author Vasya Pupkin
// @version 1.0
// @include http://fevian.org/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {         // [2] нормализуем window

    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var selectorTxt = 'div.product-more'
    var timerId = 0;

    // https://stackoverflow.com/questions/1208222/how-to-do-associative-array-hashing-in-javascript
    var dictionary = {};
    var myMap = new Map();


    // [4] дополнительная проверка наряду с @include
    if (/\/fevian.org/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('fevian_org', now);
        console.log(w.location.href);

        // MutationObserver code example
        var target = document.documentElement;
        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;

            var div = document.getElementsByTagName("deicc");
            //console.log(div.length);
            for(var i=0; i<div.length; i++) {
                div[i].remove();
            }
            console.log('callback:', timerId, mutationsList.length, div.length);
            /*
            console.log(document.cookie);
            var cookie = document.cookie.split('; ');
            for (var i = 0; i < cookie.length; ++i) {
                console.log(i, cookie[i]);
            }
            */
        };  // callback

        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        //const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        //observer.observe(target, config);

    } else {
        console.log('--------------------------------');
        console.log('fevian.org something wrong', now);
        console.log(w.location.href);
    }  // test(w.location.href)



    document.onreadystatechange = function() {
        console.log('document.readyState:', document.readyState);
        console.log('--------------------------------');

        if (document.readyState == "complete") {
            var div = document.getElementsByTagName('a');
            console.log('document.getElementsByTagName(a)', div.length, typeof(div));

            var img = document.querySelectorAll('img');  // [129]
            //var el = document.getElementsByClassName('lazy'); //[89] //document.querySelectorAll('img') // [129]
            //console.log('document.querySelectorAll(lazy):', el, el.length);
          
            /* 2021.09.19
            for(let i=0; i<img.length; i++) {
                //el[i].setAttribute('loading', 'eager')
                console.log(i, img[i].nodeName, img[i].getAttribute('loading'), img[i]); //
            }
            */

            var count = 0;

            //for (var elem in div) {  // not working
            for (var i = 0; i < div.length; ++i) {
                var elem = div[i];

                if (elem.target == "_blank") {
                    count++;
                    //console.log(i, elem);  // , elem.hostname, elem.href

                    if (dictionary[elem.hostname] == undefined) {
                        dictionary[elem.hostname] = 1;
                    } else {
                        dictionary[elem.hostname]++;
                    }

                    myMap.set(elem.hostname, 1);

                    //console.log(count, dictionary[elem.hostname], elem);
                    //console.log(i, elem);  //, elem.href .hostname

                }  // (elem.target == "_blank")

            }  // for

            console.log(count, myMap.size);
            //console.log(dictionary);

            var keysSorted = Object.keys(dictionary).sort(function(a,b){return dictionary[b]-dictionary[a]})
            console.log(keysSorted);

            //for (var key in dictionary) {
            for (var key in keysSorted) {
                console.log(keysSorted[key], dictionary[keysSorted[key]]);
            }
            //https://qarchive.ru/7515_sortirovka_ob_ekta_javascript_po_znacheniju_svoi_stva

        }  // document.readyState == "complete"

    }  // document.onreadystatechange()

})(window);

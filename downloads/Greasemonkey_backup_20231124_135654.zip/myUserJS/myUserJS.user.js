// ==UserScript==
// @name myUserJS
// @description 1st, hope not last userscript
// @author Vasya Pupkin
// @version 1.0
// @include https://*.pornhub.com/*
// ==/UserScript==

// [1] Оборачиваем скрипт в замыкание, для кроссбраузерности (opera, ie)
(function (window, undefined) {

    // [2] нормализуем window
    var w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // В юзерскрипты можно вставлять практически любые javascript-библиотеки.
    // Код библиотеки копируется прямо в юзерскрипт.
    // При подключении библиотеки нужно передать w в качестве параметра окна window
    // Пример: подключение jquery.min.js
    // (function(a,b){function ci(a) ... a.jQuery=a.$=d})(w);

    // [3] не запускаем скрипт во фреймах
    // без этого условия скрипт будет запускаться несколько раз на странице с фреймами
    if (w.self != w.top) {
        return;
    }

    var now = new Date();
    var selectorTxt = 'div.product-more'
    var timerId = 0;

    // [4] дополнительная проверка наряду с @include
    if (/\/*.pornhub.com/.test(w.location.href)) {
        //Ниже идёт непосредственно код скрипта

        //document.body.style.border = "5px solid red";
        console.log('--------------------------------');
        console.log('myUserJS', now);
        console.log(w.location.href);
        console.log('document.readyState:', document.readyState);

        //w.page_params.lazyLoad.sections = [];
          //delete w.page_params.lazyLoad;
          var el = document.querySelectorAll('img');  // [129]
          //var el = document.getElementsByClassName('lazy'); //[89] //document.querySelectorAll('img') // [129]
        //console.log('document.querySelectorAll(lazy):', el, el.length);
        for(let i=0; i<el.length; i++) {
            el[i].setAttribute('loading', 'eager')
            //console.log(i, el[i].nodeName, el[i].getAttribute('loading'), el[i]); //
        }


        var target = document.documentElement
        //https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener
        //https://habr.com/en/post/244041/
        //https://gist.github.com/dmnsgn/36b26dfcd7695d02de77f5342b0979c7


        // Конфигурация observer (за какими изменениями наблюдать)
        const config = {
            //attributes: true,
            childList: true,
            subtree: true
        };

        // Функция обратного вызова при срабатывании мутации
        const callback = function(mutationsList, observer) {
            timerId++;

            if (document.readyState == "complete") {
                /*
                //console.log('callback:', timerId, mutationsList.length);
                for (let i = 0; i < mutationsList.length; ++i) {
                    let mutation = mutationsList[i]
                    console.log(timerId, i, mutation.type, mutation);
                }
                */
                // Remove age verification
                // document.querySelector('body > script:nth-child(3)')
                // #age-verification-wrapper
                // #age-verification-container
                if (document.querySelector('body > script:nth-child(3)') != null)
                   document.querySelector('body > script:nth-child(3)').remove();

                if (document.getElementById("age-verification-wrapper") != null)
                    document.getElementById("age-verification-wrapper").remove();

                if (document.getElementById("age-verification-container") != null)
                       document.getElementById("age-verification-container").remove();

                if (document.getElementById("js-abContainterMain") != null)
                       document.getElementById("js-abContainterMain").remove();

                //console.log('age-verification pass:', timerId);
                //id=popsByTrafficJunky

                ///html/body
                var trusted_blocks = ['#text', 'DIV', 'SCRIPT', 'LINK', 'NOSCRIPT']
                var checked_blocks = ['IFRAME']  //
                var el = document.querySelector("body");
                el = el.childNodes;
                for(let i=0; i<el.length; i++) {
                    if (trusted_blocks.includes(el[i].nodeName)) {
                        if (checked_blocks.includes(el[i].nodeName)) {
                            console.log(timerId, i, el[i].nodeName, el[i])
                        }
                    } else {
                        console.log('body:', timerId, i, el[i].nodeName, 'remove')
                        el[i].remove()
                    }
                    //console.log(i, el[i].nodeName, el[i].nodeType, el[i])  //el[i].remove();  , timerId, el[i]
                }

                //cbicb.alpha
                el = document.getElementsByClassName('alpha');
                //console.log('alpha:', timerId, el);
                for(let i=0; i<el.length; i++) {
                    //console.log('alpha:', timerId, i, el[i].nodeName, 'remove')
                    el[i].remove();
                }

                ///html/body/div[9]/div/div[3]/div[1]/div[2]/div[1]
                //.r7yqzd8hv
                if (timerId == 10) {
                    el = document.getElementById('vpContentContainer');
                    if (el != null) {
                        el = el.querySelectorAll(":scope > div");
                        el = el[el.length - 1];  // <div id="1617100085775">
                        //console.log('vpContentContainer--:', timerId, el.nodeName, el.id, el)

                        //el = el.childNodes;
                        //el = el.querySelectorAll(":scope > div");
                        el = el.querySelectorAll(":scope > .clearfix");

                        for(let i=0; i<el.length; i++) {
                            console.log('clearfix:', timerId, i, el[i].nodeName, 'remove')
                            el[i].remove();
                        }
                    }
                }
                // console.log(string.includes(substring));
                //element.classList.contains(className);
                if (timerId == 11) {
                    el = document.querySelectorAll(".underplayerAd");
                    //el = document.getElementsByClassName('underplayerAd');
                    //console.log('underplayerAd:', timerId, el);
                    for(let i=0; i<el.length; i++) { //!!! cut-paste careful !!! start with 1 instesd 0 !!!
                        console.log('underplayerAd:', timerId, i, el[i].nodeName, 'remove')
                        el[i].remove();
                    }
                }
                /*
                    try {

                    } catch(e) {
                        console.log(':' + e.name + ':' + e.message + '\n' + e.stack);
                    }
                */
                //div id="hd-rightColVideoPage"
                //div class="yiizy45ohmrbmv clearfix"
                //div id="recommendedVideosVPage" class="sectionRecommended">
                el = document.getElementById('hd-rightColVideoPage');
                //console.log('rightColVideoPage:', timerId, el);
                if (el !== null) {
                    //el = el.children;
                    for(let i=0; i<el.children.length; i++) {
                        if (/sectionRecommended/.test(el.children[i].className)) {
                            //console.log('rightColVideoPage:', timerId, i, el.children[i].className);
                        } else {
                            console.log('rightColVideoPage:', timerId, i, el.children[i].className, 'remove');
                            el.children[i].remove();
                        }
                    }
                }

                el = document.getElementsByClassName('adsbytrafficjunky');
                for(let i=0; i<el.length; i++) {
                   console.log('adsbytrafficjunky:', timerId, i, el[i].parentNode.nodeName, 'remove');
                   el[i].parentNode.remove();
                }

                el = document.getElementsByClassName('adLinks');
                for(let i=0; i<el.length; i++) {
                   console.log('adLinks:', timerId, i, el[i].parentNode.nodeName, 'remove');
                   el[i].parentNode.remove();
                }

                //el = document.getElementsByClassName('greyButton light more_recommended_btn nav-videoRecommended');
                el = document.querySelector('a.greyButton:nth-child(4)');
                //console.log('greyButton:', timerId, el);  //: "Load More" "Show Less"
                if (el !== null) {
                    if (/Load More/.test(el.innerText)) {
                        el.click();
                    }
                }
                //console.log('greyButton pass:', timerId, mutationsList.length);

                /*
                el = document.getElementsByClassName('greyButton light more_recommended_btn nav-videoRecommended');
                for(let i=0; i<el.length; i++) {
                   //console.log('more_recommended_btn:', timerId, i, el[i]);
                   if (/Load More/.test(el[i].innerText)) {
                      console.log('more_recommended_btn: Load More', timerId, i, el[i]);
                   } else {
                      console.log('more_recommended_btn: Load Less', timerId, i, el[i]);
                   }
                  //innerText: "Load More"
                }
                console.log('--------------------------------');
              */
                //console.log('-------------------------------- document.readyState == "complete"');
            } //if (document.readyState == "complete")

              /*
              console.log(document.cookie);
              var cookie = document.cookie.split('; ');
                for (var i = 0; i < cookie.length; ++i) {
                console.log(i, cookie[i]);
            }
            */
        }; //callback()

        // Создаем экземпляр наблюдателя с указанной функцией обратного вызова
        const observer = new MutationObserver(callback);

        // Начинаем наблюдение за настроенными изменениями целевого элемента
        observer.observe(target, config);


    } else {
        console.log('--------------------------------');
        console.log('myUserJS something wrong', now);
        console.log(w.location.href);
    }

    document.onreadystatechange = function() {
        //console.log('document.readyState:', document.readyState);
        console.log('--------------------------------');

        if (document.readyState == "complete") {

            //https://dev.to/martyhimmel/animating-sprite-sheets-with-javascript-ag3
            //https://medium.com/dailyjs/how-to-build-a-simple-sprite-animation-in-javascript-b764644244aa

            if (/viewkey/.test(w.location.href)) {
                //console.log('loadScriptVar=', typeof w.loadScriptVar);
                //console.log('loadScriptVar=', w.loadScriptVar.length);
                //console.log('loadScriptVar=', w.loadScriptVar[0]);

                var flashvars = null;
                var qualityItems = "";  //qualityItems_385126871
                var videoID = "";
		            //console.log('w.loadScriptVar:', w.loadScriptVar);
              
                //var flashvars_284770292 = {"maxInitialBufferLength":10,"disable_sharebar":0,"htmlPauseRoll":"true","htmlPostRoll":"true","errorReports":"https:\/\/www.pornhub.com\/video\/problems\/284770292","autoplay":"true","autoreplay":"false","enableBitmovinDebug":false,"video_unavailable":"false","pauseroll_url":"","postroll_url":"","embedCode":"<iframe src=\"https:\/\/www.pornhub.com\/embed\/ph5e47dd8f1f1f0\" frameborder=\"0\" width=\"560\" height=\"340\" scrolling=\"no\" allowfullscreen><\/iframe>","hidePostPauseRoll":false,"isHD":"true","video_duration":"7127","actionTags":"","link_url":"https:\/\/www.pornhub.com\/view_video.php?viewkey=ph5e47dd8f1f1f0","related_url":"https:\/\/www.pornhub.com\/video\/player_related_datas?id=284770292","image_url":"https:\/\/ai.phncdn.com\/videos\/202002\/15\/284770292\/original\/(m=eaAaGwObaaaa)(mh=sVhZ_QqHyEs6q7sZ)12.jpg","video_title":"kv-154 \u304a\u3057\u3083\u3076\u308a\u4e88\u5099\u6821\u3000\u685c\u4e95\u3042\u3086","defaultQuality":[480,240,720,1080],"vcServerUrl":"\/svvt\/add?stype=svv&svalue=284770292&snonce=b2jze3oxumazyqtc&skey=9e6b1b00da969f52b7c9f5161c098ba3ebf2920d62a16d03fee03d6aac56d8d1&stime=1586344149","display_hd_upsell":true,"mediaDefinitions":[{"defaultQuality":false,"format":"mp4","quality":"1080","videoUrl":""},{"defaultQuality":false,"format":"hls","videoUrl":"","quality":"1080"},{"defaultQuality":false,"format":"mp4","quality":"720","videoUrl":""},{"defaultQuality":false,"format":"hls","videoUrl":"","quality":"720"},{"defaultQuality":false,"format":"mp4","quality":"480","videoUrl":""},{"defaultQuality":true,"format":"hls","videoUrl":"","quality":"480"},{"defaultQuality":false,"format":"mp4","quality":"240","videoUrl":""},{"defaultQuality":false,"format":"hls","videoUrl":"","quality":"240"},{"defaultQuality":720,"format":"hls","videoUrl":"","quality":[1080,720,480,240]}],"isVertical":"false","video_unavailable_country":"false","mp4_seek":"start","hotspots":[15690,2571,2332,2101,1972,2404,2302,1874,1743,1634,1623,1412,1225,1254,1414,1791,1898,1512,1458,1346,1281,1235,1042,1110,1055,856,800,786,737,747,914,1007,1077,1134,1223,1337,1983,1380,1024,1056,1039,815,738,753,771,658,670,673,719,736,887,1205,1026,755,755,798,718,591,651,651,568,522,534,484,546,530,507,555,607,708,1007,826,595,556,570,512,503,454,517,476,425,409,439,484,497,507,748,817,547,464,420,422,490,450,455,399,410,404,391,378,381,487,833,613,451,458,439,467,370,321,322,289,288,317,362,549,520,396,368,397,412,368,313,442,360,362,362,365,353,333,316,334,379,465,630,850,703,575,442,413,365,405,417,839,946,772,746,736,740,673,479,363,360,322,291,355,300,346,492,617,423,384,366,316,355,327,347,381,542,424,385,383,437,599,427,362,319,404,493,363,319,258,263,365,348,316,400,621,624,763,1209,1278,753,533,409,516,497,516,729,1456,1021,735,539,286],"toprated_url":"https:\/\/www.pornhub.com\/video?o=tr&t=m","mostviewed_url":"https:\/\/www.pornhub.com\/video?o=mv&t=m","options":"show","cdn":"highwinds","startLagThreshold":1000,"outBufferLagThreshold":2000,"appId":"1111","service":"protrack","cdnProvider":"hw","tubesCmsPrerollConfigType":"new","prerollGlobalConfig":{"delay":[900,2000,3000],"forgetUserAfter":86400,"onNth":1,"skipDelay":5,"skippable":true,"vastSkipDelay":false,"vast":"https:\/\/ads.trafficjunky.net\/ads?zone_id=1845481&site_id=2&channel%5Bcontext_tag%5D=petite%2Cjapanese-deepthroat%2Cteenager%2Cyoung%2Cbrunette%2Cteen%2Cbabe%2Cmasturbation%2Cfingering%2Chairy-pussy%2Csmall-boobs%2Csmall-ass%2Cblowjob%2Csex%2Ccreampie&channel%5Bcontext_category%5D=Blowjob%2CCumshot%2CPornstar%2CPOV%2CCompilation%2CSmall-Tits%2CPopular-With-Women%2CJapanese&channel%5Bcontext_pornstar%5D=Ayu-Sakurai&cache=1586344149&t_version=2020040703.ded6727&channel%5Bsite%5D=pornhub","user_accept_language":"en-US,en;q=0.5"},"thumbs":{"samplingFrequency":10,"type":"normal","cdnType":"regular","urlPattern":"https:\/\/ai.phncdn.com\/videos\/202002\/15\/284770292\/timeline\/160x90\/(m=eGCaiCObaaaa)(mh=5eKokQiUMuMfunNM)S{28}.jpg","thumbHeight":"90","thumbWidth":"160"},"nextVideo":{"thumb":"https:\/\/ai.phncdn.com\/videos\/201906\/18\/230110162\/original\/(m=ecuKGgaaaa)(mh=ve-KL8aEPCnutCF9)8.jpg","duration":"3314","title":"Pacifier preparatory school 47","isHD":"1","nextUrl":"\/view_video.php?viewkey=ph5d08c304dcbf7","video":"https:\/\/cw.phncdn.com\/videos\/201906\/18\/230110162\/180P_225K_230110162.webm?S93ZPX32FY0uHuW1v2al8YM1Oq0rdWwWI9F0lwzzdMkoLlkcAIifZ3g_41r1QY4S8D55hu1e13Ew7Cr99buGUfI2wCHUsDPOTqN2Uv8XTsWT7Ey5CnSB659lSpdtELBV-H0UD74b9zkTgfofH0r_vZOdDzUGK_TvWiI6t87CCkSUt8eAdpEnKkKDcqFPVgC0V81ajc_F90Q","vkey":"ph5d08c304dcbf7","isJoinPageEntry":false,"channelTitle":null},"language":"en","isp":"e-light-telecom ltd.","geo":"russia"};
                try {
                    result = document.body.innerHTML.match( /var\s+(flashvars_\d+)\s*=\s*(.*?)\};/ );
                    //result[1] 'flashvars_284770292'
                  	videoID = result[1].split('_')[1];
		             		console.log('videoID:', videoID, result[1]);
                      
                    flashvars = eval('w.' + result[1]);
                    qualityItems = eval('w.qualityItems_' + videoID);
                } catch(e) {
                    console.log('result = w.match\n' + e.name + ':' + e.message + '\n' + e.stack);
                }
              
                //console.log('flashvars:');
                //console.log(flashvars.mediaDefinitions);  //mediaDefinitions
                //console.log('qualityItems:');
                //console.log(qualityItems);
                //console.log(flashvars.link_url);
                //console.log(flashvars.video_title);
                //console.log(flashvars.image_url);

                var title = 'xxx_';

                //https://ci.phncdn.com/videos/201907/02/232864791/original/(m=eaAaGwObaaaa)(mh=njG_ilBgm47QYVkG)3.jpg
                var tmp = flashvars.image_url;
                var result = tmp.match( /com\/videos\/(\d\d\d\d\d\d\/\d\d)\// );
                if ( result ) {  // image_url
                    result = result[1];  //201907/02
                    //console.log('data:'+ result.replace('\/', '-'));
                    title += result.substring(2, 4) + '-' + result.substring(4, 6) + '-' + result.substring(7) + '_'
                    //console.log(title);
                }  // image_url

                //https://www.pornhub.com/view_video.php?viewkey=ph5d1b4a04f4115
                tmp = flashvars.link_url;
                result = tmp.match( /\?viewkey(.*?)$/ );
                if ( result ) {  // link_url
                    result = result[1];  //=ph5d1b4a04f4115
                    title += flashvars.video_title + result;
                    console.log(title + '.mp4');
                    console.log(flashvars.thumbs.urlPattern);
                    console.log('next: ' + flashvars.nextVideo.title + ' : ' + flashvars.nextVideo.nextUrl);
                }  // link_url

                console.log('-------------------------------- Right click -> Copy Object');
              
                console.log('qualityItems:');
                //console.log(qualityItems);
                for(var i=0; i<qualityItems.length; i++) {
                    console.log(i, qualityItems[i].text);
                    console.log(i, qualityItems[i].url);
                    //if (mediaDefinitions[i].format == 'mp4') {
                    //    console.log(i, mediaDefinitions[i].quality);
                    //    console.log(mediaDefinitions[i].videoUrl);
                    //}
                }

                /*
                var mediaDefinitions = flashvars.mediaDefinitions;
                //console.log('mediaDefinitions:', mediaDefinitions);
                //https://habr.com/ru/post/247857/ способы перебора массива в JavaScript
                for(var i=0; i<mediaDefinitions.length; i++) {
                    console.log(i, mediaDefinitions[i]);
                    if (mediaDefinitions[i].format == 'mp4') {
                        console.log(i, mediaDefinitions[i].quality);
                        console.log(mediaDefinitions[i].videoUrl);
                    }
                }
                */
                console.log('-------------------------------- end');
            } else {// /viewkey/.test(w.location.href)

                console.log('No viewkey --------------------------------');
              //https://github.com/Infocatcher/Right_Links_WE

                  /*
                const listeners = (function listAllEventListeners() {

                    let dict = {};
                    let evMap = new Map();
                    let tagMap = new Map();

                    let elements = [];
                    const allElements = document.querySelectorAll('*');
                    const types = [];

                    for (let ev in w) {
                        if (/^on/.test(ev)) types[types.length] = ev;
                    }

                    for (let i = 0; i < allElements.length; i++) {

                        const currentElement = allElements[i];
                        for (let j = 0; j < types.length; j++) {
                            if (typeof currentElement[types[j]] === 'function') {
                                elements.push({
                                    "node": currentElement,
                                    "listeners": [ {
                                        "type": types[j],
                                        "func": currentElement[types[j]].toString(),
                                    }]
                                });
                            }

                        }
                    }
                    return elements //.filter(element => element.listeners.length)



                  for (let ev in w) {
                      if (/^on/.test(ev)) types[types.length] = ev;  //471  //112
                  }
                  console.log('events:', types.length);


                  for(let tag of document.querySelectorAll('*')) {

                    //const events = w.getEventListeners(tag);

                    for(let ev of types) {

                      //let t = typeof tag[ev]; // undefined, object, function, string, number

                      if (typeof tag[ev] === 'function') {

                        let t = tag[ev].toString();

                        if (/ga/.test(t)) {

                        } else { // ga.test

                        if (dict[t] == undefined) {
                          dict[t] = 1;
                        } else {
                          dict[t]++;
                        }

                        }  // ga.test

                      }


                    }
                  }
                  console.log('tags:', allElements.length);

                  console.table(dict);

                  return types //.filter(element => element.listeners.length)
                })();

                //console.table(listeners);

                  */


            } //.test(w.location.href)

        } // document.readyState == "complete"

    } // document.onreadystatechange

})(window);

/*
addMonitor
addEventListener
removeEventListener
dispatchEvent

undefined, object, function, string, number

focus     3166
blur      3166
scroll    3166
scrollTo  3166
scrollBy  3166
remove    3166
addEventListener     3166
removeEventListener  3166
dispatchEvent        3166
onload                  6
onclick               147
onmessage               1

function(){htUrl="hubt.pornhub.com"}
1
function(e){e&&e.origin&&!(e.origin.indexOf(t)>=0)||c||(c=!0,h())}
1
function onclick(event) {
ga('send', 'event', 'Login Page', 'click', 'Lost Password');
}
1
function onclick(event) {
ga('send', 'event', 'Login Page', 'click', 'Resend Confirmation');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Logo');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Upload');
}
2
function onclick(event) {
triggerGatewayModal(event);ga('send', 'event', 'Header', 'click', 'upgrade');
}
1
function onclick(event) {
signinbox.show(); ga('send', 'event', 'Header', 'click', 'Login'); return false;
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Sign Up');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Home Tab');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Videos Tab');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Recommended');
}
3
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Hottest');
}
3
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Most Viewed');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Top Rated');
}
3
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Homemade');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Playlists');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Channels');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Random');
}
1
function onclick(event) {
triggerGatewayModal(event); ga('send', 'event', 'Header', 'click', 'upgrade');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Newest');
}
1
function onclick(event) {
return false;
}
36
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Categories Tab');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 36');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 37');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 29');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 35');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 17');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 111');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 28');
}
1
function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 86');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 3');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 8');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 27');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 181');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 65');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 24');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 10');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 83');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 15');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 80');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 7');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Category 5');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Categories');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Live Sex Tab');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Porn Stars Tab');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Real Sex Tab');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Community Tab');
}
1

function onclick(event) {
ga('send', 'event', 'Header', 'click', 'Photos Tab');
}
1

function onclick(event) {
triggerGatewayModal(event, false, undefined, undefined, undefined);
}
1

function onclick(event) {
hideUserMessage();
}
1

function onclick(event) {
ga('send', 'event', 'Video Page', 'click', 'Channels Button');
}
1

function onclick(event) {
setCookieAndRedirect(event, 'cf', 104)
}
3

function onclick(event) {
setCookieAndRedirect(event, 'cf', 86)
}
9

function onclick(event) {
setCookieAndRedirect(event, 'cf', 36)
}
9

function onclick(event) {
setCookieAndRedirect(event, 'cf', 27)
}
7

function onclick(event) {
setCookieAndRedirect(event, 'cf', 65)
}
7

function onclick(event) {
setCookieAndRedirect(event, 'cf', 83)
}
4

function onclick(event) {
triggerGatewayModal(event);
}
2

function onclick(event) {
javascript:void(0);
}
3

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Deutsch');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Français');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Español');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Italiano');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Português');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Polski');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Русский');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', '日本語');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Dutch');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', 'Czech');
}
1

function onclick(event) {
ga('send', 'event', 'Language Flags Footer', 'click', '中文(简体)');
}
1

function onload(event) {
this.media='all'
}
5

*/
